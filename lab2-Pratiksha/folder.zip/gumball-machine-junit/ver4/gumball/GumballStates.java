package gumball;


public enum GumballStates { HAS_QUARTER, NO_QUARTER }
