package gumball;


/**
 * Write a description of class GumballStub2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GumballStub2 implements IGumball
{

    /**
     * Constructor for objects of class GumballStub2
     */
    public GumballStub2()
    {
    }

 public void insertQuarter() throws GumballException
    { 
        
    }
    
    public void turnCrank() throws GumballException
    { 
       
    }
    
    public boolean hasGumball() { 
        return true ;
    }
    
    public String takeGumball() {
        return "" ;
    }   
}
