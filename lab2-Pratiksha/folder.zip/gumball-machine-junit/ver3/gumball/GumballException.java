package gumball;

public class GumballException extends Exception
{
  
}
