package gumball;


/**
 * Write a description of interface IGumball here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface IGumball
{

    public void insertQuarter() ;
    public void turnCrank() ;
    public boolean hasGumball() ;
}
