package gumball;


/**
 * Write a description of class GumballStub here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GumballStub implements IGumball
{

    public void insertQuarter() {}
    public void turnCrank() {}
    public boolean hasGumball() { return true; }
}
